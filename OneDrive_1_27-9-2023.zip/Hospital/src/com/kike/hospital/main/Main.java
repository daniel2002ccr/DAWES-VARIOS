package com.kike.hospital.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.kike.hospital.vistas.MenuPrincipal;
import com.kike.hospital.vistas.VistaAlergias;

class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

	
		MenuPrincipal mp = new MenuPrincipal();
		mp.menuPrincipal();

	}

}
